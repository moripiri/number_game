import json
from mangum import Adapter
from app.main import app

# Create handler for AWS Lambda
handler = Adapter(app)

# Optional: Add logging for debugging
def lambda_handler(event, context):
    print(f"Event: {json.dumps(event)}")
    return handler(event, context) 